#!/usr/bin/env bash
echo "Starting Edited! Web App..."
python3 app.py
