# Edited! ⚡ — Autonomous AI Video Retention Agent

> **Built for the Meta Global AI Developer Hackathon 2026**  
> **Theme:** *Build for Your World*  
> **Powered by:** Meta Muse Wonder 1.0 (`dev.meta.ai`) & FFmpeg

---

## 🎯 The Problem & Our World

Editing 15 minutes of raw creator footage into high-retention vertical clips (TikTok, Shorts, Reels) takes **2 to 3 hours every day**. Most creators get burned out or post unedited, low-retention videos that fail to hold attention.

**Edited!** is an autonomous video editing agent built for creators and founders. Instead of a basic chatbot or generic dashboard, **Edited!** is an intelligent agent that:
1. **Watches & analyzes** raw footage.
2. **Spots retention hooks** using **Meta Muse Wonder 1.0** reasoning.
3. **Explains the psychology** of why each hook stops scrolling (curiosity gaps, pattern interrupts, stakes).
4. **Executes vertical 9:16 cuts** with FFmpeg automatically.

*(Note: In accordance with hackathon rules, this is a custom-engineered modern web app — **zero Streamlit templates**).*

---

## 🧠 System Architecture

```text
[ Raw MP4 Video ] 
       │
       ▼
[ Audio / Narrative Extraction ]
       │
       ▼
[ Meta Muse Wonder 1.0 Agent (api.meta.ai) ]
       │ ──> Analyzes spoken pacing & viewer retention
       │ ──> Scores viral potential (0-100)
       │ ──> Identifies exact cut timestamps (start/end)
       │ ──> Generates high-CTR headline & hashtags
       ▼
[ Autonomous FFmpeg Engine ]
       │ ──> 9:16 Fullscreen smart crop or blurred background
       │ ──> H.264 / AAC encoding with fast-start streaming
       ▼
[ Production-Ready 9:16 MP4 Clip ]
```

---

## 🚀 Quickstart (30 Seconds)

### 1. Prerequisites
- Python 3.10+
- FFmpeg installed in system PATH (`ffmpeg -version`)

### 2. Install Dependencies
```bash
pip install -r requirements.txt
```

### 3. Launch App
**On Windows:**
Double-click `run.bat` or run:
```bash
python app.py
```

**On macOS / Linux:**
```bash
python3 app.py
```

Open your browser at **`http://localhost:8000`**.

---

## 🔑 Meta API Credentials

Set your Meta model API key from [dev.meta.ai](https://dev.meta.ai):
```bash
# Windows PowerShell:
$env:MODEL_API_KEY="your-meta-api-key"

# Mac/Linux:
export MODEL_API_KEY="your-meta-api-key"
```
*Or configure it directly through the UI via the "Configure API Key" button in the top navigation.*

---

## 🎬 3-Minute Demo Guide for Judges

1. **Step 1:** Drag and drop any raw video file (`.mp4`).
2. **Step 2:** Click **"Analyze & Detect Viral Hooks"** — watch the live Agent Reasoning Terminal query Meta Muse.
3. **Step 3:** Review the hook cards, retention scores, and psychological explanations.
4. **Step 4:** Click **"Render 9:16 Clip"** — watch FFmpeg crop the video into a vertical short in under 5 seconds.
5. **Step 5:** Play the preview and download the finished MP4 ready for social platforms.

---

## 🏆 Hackathon Details
- **Event:** Meta Global AI Developer Hackathon 2026 (Cerebral Valley)
- **Track:** Build for Your World
- **Model:** Meta Muse Wonder 1.0 (`muse-wonder-1.0`)
- **License:** MIT
